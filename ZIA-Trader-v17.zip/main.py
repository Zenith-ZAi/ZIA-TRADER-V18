import asyncio

async def main():
    print("ZIA v17 running")

if __name__ == "__main__":
    asyncio.run(main())
